# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: coach.spec.cjs >> resignation is a legitimate path, keeps that decision, and receives relevant reflection
- Location: tests/coach.spec.cjs:56:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#send')
    - locator resolved to <button id="send" type="button" class="primary">Say this →</button>

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - link "HUMAN LITERACY" [ref=e4] [cursor=pointer]:
      - /url: ../../
    - link "← Home" [ref=e5] [cursor=pointer]:
      - /url: ../../
  - generic [ref=e6]:
    - generic [ref=e7]: Life Simulator · Prototype 01
    - heading "The Missed Deadline" [level=1] [ref=e8]
    - paragraph [ref=e9]: Practise clarity, boundaries and next steps in a scripted, fictional workplace. Choose or write a reply, then Say this. Different approaches can lead to different possible outcomes. Mistakes are welcome; you control your words and decisions.
  - main [ref=e10]:
    - group [ref=e11]:
      - generic "Jordan’s question" [ref=e12] [cursor=pointer]
      - region "Workplace conversation" [ref=e13]:
        - generic [ref=e14]:
          - generic [ref=e15]: WORKPLACE · PRIVATE OFFICE
          - generic [ref=e16]: SCENE 2 OF 2
        - group [ref=e17]:
          - generic "View illustration" [ref=e18] [cursor=pointer]
        - generic [ref=e19]:
          - generic [ref=e20]: Jordan · Your manager
          - paragraph [ref=e21]: You have said you are resigning. I will not treat that as agreement to finish this assignment. What practical details would you like to clarify?
    - region [ref=e22]:
      - heading "What do you do now?" [level=2] [ref=e23]
      - paragraph [ref=e24]: Choose wording to put it in your draft, or write your own. Only Say this sends it to Jordan. No grade.
      - generic [ref=e25]:
        - button "“I am confirming my decision to resign. Let us clarify notice and any handover.”" [ref=e26] [cursor=pointer]
        - group [ref=e27]:
          - generic "More responses (1)" [ref=e28] [cursor=pointer]
      - status [ref=e29]: Suggestion added to your draft. Edit it, then choose Say this.
      - generic [ref=e30]:
        - paragraph [ref=e31]: "Selected goal: Leave or resign from the job. Editing your words keeps this goal."
        - button "Clear goal" [ref=e32] [cursor=pointer]
      - generic [ref=e33]: Or use your own words
      - textbox "Or use your own words" [active] [ref=e34]:
        - /placeholder: Type what you would say…
        - text: I am confirming my decision to resign. Let us clarify notice and any handover.
      - generic [ref=e35]:
        - button "Say this →" [ref=e36] [cursor=pointer]
        - button "Help me draft a response" [ref=e37] [cursor=pointer]: Help me draft
    - navigation "Conversation progress" [ref=e38]:
      - generic [ref=e39]:
        - button "← Back" [ref=e40] [cursor=pointer]
        - button "Forward →" [disabled] [ref=e41]
      - status [ref=e42]: Reply sent. Back reviews earlier replies; Say this on an earlier reply replaces later replies.
    - group [ref=e43]:
      - generic "Private drafting" [ref=e44] [cursor=pointer]
      - option "Choose your own path…"
      - option "Decline or hold a firm boundary"
      - option "Leave or resign from the job" [selected]
      - option "Renegotiate scope, time, or expectations"
      - option "Communicate distress or ask for support"
      - option "Pause the conversation without resigning"
      - option "Discuss accountability and a recovery plan"
      - option "Another goal / I want to clarify it myself"
    - group [ref=e45]:
      - generic "Conversation so far" [ref=e46] [cursor=pointer]
  - contentinfo [ref=e47]:
    - group [ref=e48]:
      - generic "About this scripted prototype" [ref=e49] [cursor=pointer]
      - text: This prototype uses authored dialogue and simple rules, not an AI-powered live video character. The coach uses curated examples and learner-chosen goals; it cannot know your feelings or intentions. Outcomes vary in real workplaces. No account or site analytics are used by this page. Local recording stays in page memory. Optional browser dictation has a separate external-service consent choice.
```

# Test source

```ts
  1   | const { reveal, feedback } = require('./review-helpers.cjs');
  2   | const { test, expect } = require('@playwright/test');
  3   | 
  4   | test.beforeEach(async ({ page }) => {
  5   |   page.errors = [];
  6   |   page.on('pageerror', error => page.errors.push(error.message));
  7   |   await page.goto('/simulator/01/');
  8   |   await page.locator('#openPractice').click();
  9   | });
  10  | test.afterEach(async ({ page }) => { expect(page.errors).toEqual([]); });
  11  | 
  12  | async function understand(page, words) {
  13  |   await page.locator('#expressWords').fill(words);
  14  |   await page.getByRole('button', { name: 'Next: choose what I want to communicate', exact: true }).click();
  15  |   await expect(page.locator('#coachLiteral')).toHaveText(words);
  16  |   await expect(page.locator('#coachUnderstandingTitle')).toBeFocused();
  17  | }
  18  | async function confirm(page) {
  19  |   await page.getByRole('button', { name: 'Use my goal and show options' }).click();
  20  |   await expect(page.locator('.coach-option')).toHaveCount(3);
  21  | }
  22  | async function moveFirst(page) {
  23  |   await page.locator('.coach-option button').first().click();
  24  |   await expect(page.locator('#sceneProgress')).toHaveText('SCENE 1 OF 2');
  25  |   await expect(page.locator('#history .bubble')).toHaveCount(1);
  26  |   await expect(page.locator('#yourReply')).toBeFocused();
  27  | }
  28  | async function completeCoachedRoleplay(page) {
  29  |   await page.locator('#send').click();
  30  |   await expect(page.locator('#sceneProgress')).toHaveText('SCENE 2 OF 2');
  31  |   await page.locator('#choices button').first().click();
  32  |   await page.locator('#send').click();
  33  |   await expect(page.locator('#sceneProgress')).toHaveText('SIMULATION COMPLETE');
  34  |   await expect(page.locator('#scoreArea')).toBeHidden();
  35  | }
  36  | 
  37  | test('strong expression has a tentative, rejectable reading and can preserve a firm refusal', async ({ page }) => {
  38  |   await understand(page, 'You all can kiss my ass');
  39  |   await expect(page.locator('#coachTentative')).toContainText('might');
  40  |   await expect(page.locator('#coachTentative')).toContainText('do not tell us your feelings');
  41  |   await expect(page.locator('#coachPath')).toHaveValue('boundary');
  42  |   await page.locator('#coachGoal').fill('I want to refuse this request while keeping my boundary.');
  43  |   await confirm(page);
  44  |   await expect(page.locator('#coachChosenGoal')).toContainText('keeping my boundary');
  45  |   await moveFirst(page);
  46  |   await expect(page.locator('#yourReply')).toHaveValue(/not accepting this request/);
  47  |   await completeCoachedRoleplay(page);
  48  |   await expect(page.locator('#madeClear')).toContainText('refusal or limit');
  49  |   await expect(page.locator('#outcome')).toContainText('refusal or limit');
  50  |   await expect(page.locator('#realWorldPractice')).toContainText('decline');
  51  |   await feedback(page);
  52  |   await expect(page.locator('#score')).toHaveCount(0);
  53  |   await expect(page.locator('#scoreDetails')).toContainText('No numerical rubric');
  54  | });
  55  | 
  56  | test('resignation is a legitimate path, keeps that decision, and receives relevant reflection', async ({ page }) => {
  57  |   await understand(page, 'The expectations are unreasonable. I quit');
  58  |   await expect(page.locator('#coachPath')).toHaveValue('resign');
  59  |   await expect(page.locator('#coachTentative')).toContainText('legitimate choice');
  60  |   await confirm(page);
  61  |   for (const input of await page.locator('.coach-option textarea').all()) {
  62  |     expect(await input.inputValue()).toMatch(/resign|leave this job/);
  63  |   }
  64  |   await moveFirst(page);
  65  |   await expect(page.locator('#yourReply')).toHaveValue(/I am resigning/);
  66  |   await page.locator('#send').click();
  67  |   await expect(page.locator('#bossWords')).toContainText('not treat that as agreement to finish');
  68  |   await expect(page.locator('#choices')).toContainText('decision to resign');
  69  |   await page.locator('#choices button').first().click();
> 70  |   await page.locator('#send').click();
      |                               ^ Error: locator.click: Test timeout of 30000ms exceeded.
  71  |   await expect(page.locator('#reflectionBasis')).toContainText('resign');
  72  |   await expect(page.locator('#madeClear')).toContainText('resign');
  73  |   await expect(page.locator('#unresolved')).toContainText('final pay');
  74  |   await expect(page.locator('#realWorldPractice')).toContainText('resignation statement');
  75  |   await expect(page.locator('#realWorldPractice')).not.toContainText('realistically commit');
  76  | });
  77  | 
  78  | test('scope-change alternatives name facts, limits and options; learner edits are preserved', async ({ page }) => {
  79  |   await understand(page, 'I need more time because the scope changed');
  80  |   await expect(page.locator('#coachPath')).toHaveValue('scope');
  81  |   await confirm(page);
  82  |   const options = await page.locator('.coach-option textarea').evaluateAll(nodes => nodes.map(n => n.value));
  83  |   expect(options[0]).toContain('cannot meet the original deadline');
  84  |   expect(options[1]).toContain('reducing the work, adjusting the deadline, or adding support');
  85  |   expect(options[2]).toContain('before I commit');
  86  |   const ownWords = 'The scope changed. I cannot do both tasks by Friday. Can we reduce the scope or extend the deadline?';
  87  |   await page.locator('.coach-option textarea').first().fill(ownWords);
  88  |   await moveFirst(page);
  89  |   await expect(page.locator('#yourReply')).toHaveValue(ownWords);
  90  |   await completeCoachedRoleplay(page);
  91  |   await expect(page.locator('#unresolved')).toContainText('scope');
  92  |   await expect(page.locator('#realWorldPractice')).toContainText('what changed');
  93  | });
  94  | 
  95  | test('unexpected wording asks for clarification rather than inventing an interpretation', async ({ page }) => {
  96  |   await understand(page, 'Purple umbrellas orbit the pancake moon.');
  97  |   await expect(page.locator('#coachStatus')).toContainText('Please clarify');
  98  |   await expect(page.locator('#coachHearing')).toContainText('do not have a scripted reading');
  99  |   await expect(page.locator('#coachGoal')).toHaveValue('');
  100 |   await expect(page.locator('#coachPath')).toHaveValue('');
  101 |   await expect(page.locator('#coachChoices')).toBeHidden();
  102 |   await page.locator('#coachConfirm').click();
  103 |   await expect(page.locator('#coachChoices')).toBeHidden();
  104 |   await expect(page.locator('#coachPath')).toBeFocused();
  105 |   await page.locator('#coachPath').selectOption('custom');
  106 |   await page.locator('#coachGoal').fill('I want to ask a question about the situation.');
  107 |   await confirm(page);
  108 |   await expect(page.locator('#coachWording0')).toHaveValue(/ask a question/);
  109 | });
  110 | 
  111 | test('unknown free-form roleplay wording does not receive a fabricated numerical score', async ({ page }) => {
  112 |   await page.locator('#returnToReply').click();
  113 |   await page.locator('#yourReply').fill('flibberty pancake moon');
  114 |   await page.locator('#send').click();
  115 |   await page.locator('#yourReply').fill('purple orbital teapot');
  116 |   await page.locator('#send').click();
  117 |   await feedback(page);
  118 |   await expect(page.locator('#score')).toHaveCount(0);
  119 |   await expect(page.locator('#scoreDetails')).toContainText('unrecognized wording');
  120 |   await expect(page.locator('#realWorldPractice')).toContainText('one question');
  121 | });
  122 | 
  123 | test('rejecting an interpretation leaves the expression intact and lets the learner choose another goal', async ({ page }) => {
  124 |   await understand(page, 'You all can kiss my ass');
  125 |   await confirm(page);
  126 |   await page.locator('#coachReview > summary').click();
  127 |   await reveal(page, 'readingDetails');
  128 |   await page.locator('#coachReject').click();
  129 |   await expect(page.locator('#coachChoices')).toBeHidden();
  130 |   await expect(page.locator('#coachPath')).toHaveValue('');
  131 |   await expect(page.locator('#coachGoal')).toHaveValue('');
  132 |   await expect(page.locator('#coachTentative')).toContainText('choose a different path');
  133 |   await expect(page.locator('#expressWords')).toHaveValue('You all can kiss my ass');
  134 |   await page.locator('#coachPath').selectOption('pause');
  135 |   await page.locator('#coachGoal').fill('I want a pause, not resignation.');
  136 |   await confirm(page);
  137 |   await moveFirst(page);
  138 |   await completeCoachedRoleplay(page);
  139 |   await expect(page.locator('#realWorldPractice')).toContainText('asking for a pause');
  140 | });
  141 | 
  142 | test('editing the goal or source expression invalidates stale suggestions', async ({ page }) => {
  143 |   await understand(page, 'The expectations are unreasonable. I quit');
  144 |   await confirm(page);
  145 |   await page.locator('#coachReview > summary').click();
  146 |   await page.locator('#coachGoal').fill('I want to leave after clarifying notice.');
  147 |   await expect(page.locator('#coachChoices')).toBeHidden();
  148 |   await confirm(page);
  149 |   await expect(page.locator('#coachChosenGoal')).toContainText('clarifying notice');
  150 |   await page.locator('#coachEditExpression').click();
  151 |   await page.locator('#expressWords').fill('Something different');
  152 |   await expect(page.locator('#coachUnderstanding')).toBeHidden();
  153 |   await expect(page.locator('#coachOptions')).toBeEmpty();
  154 |   await expect(page.locator('#coachGoal')).toHaveValue('');
  155 | });
  156 | 
  157 | test('an entirely custom rehearsal is not overwritten or auto-submitted by the coach', async ({ page }) => {
  158 |   await understand(page, 'I need more time because the scope changed');
  159 |   await confirm(page);
  160 |   await reveal(page, 'rehearsalPanel');
  161 |   await page.locator('#practiceWords').fill('I will not commit before we clarify which work matters.');
  162 |   await reveal(page, 'rehearsalPanel');
  163 |   await page.locator('#practiceTransfer').click();
  164 |   await expect(page.locator('#yourReply')).toHaveValue('I will not commit before we clarify which work matters.');
  165 |   await expect(page.locator('#history .bubble')).toHaveCount(1);
  166 | });
  167 | 
  168 | test('coaching uses no uploads, outside requests, cookies, or persistent storage', async ({ page }) => {
  169 |   const requests = [];
  170 |   page.on('request', r => requests.push({ url: r.url(), method: r.method() }));
```