UNRELEASED HUMAN LITERACY REVIEW — 318 full-suite cases
Verified CI results and the separate local-run status are in results.json.

In the local preview choose View the review packet. It opens through the same
private authenticated loopback session; no extraction or extra software needed.
The ZIP is an optional copy. If Chrome blocks file:// HTML, serve the extracted
folder with: python3 -m http.server 8000 --bind 127.0.0.1
Then open http://localhost:8000/ on that computer. No public hosting is involved.

Founder checks (three only):
1. Say "Please leave me alone"; confirm it ends, then use Back/Forward.
2. Submit a final resignation and choose Finish here; check offboarding and takeaway.
3. Try one private drafting goal or optional local recording/listen-back.

reviewedRuntimeRevision: 110476cfc47b93ad69260848be2bf1ae1f1f2dbe
runtimeHash: 0dddc6a64aa2736c1ea686cda2552a4e8226964e0fe6273be79fe40d363454d9
The final source SHA appears in the pinned launch block and preview banner.
The archive cannot contain the hash of its own containing commit. The launcher
verifies the entire final source archive; verify_preview.cjs checks all captured
runtime hashes against that exact revision, the actual pages and assets, two
fresh launches and the rendered packet/report. It tests the simulator's zero
storage of answers separately from the report's harmless UI theme preference.

All screenshots and traces use fictional typed inputs. Any video is silent;
there is no microphone recording, private founder response or private register.
Language remains scripted. Hardware audio, live speech-provider behavior and
screen-reader output have not been manually validated. Typing remains available.
No merge, public release, deployment or spending is authorized.
