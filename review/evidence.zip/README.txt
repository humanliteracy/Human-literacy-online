UNRELEASED HUMAN LITERACY REVIEW — 265 full-suite cases
Full CI results and separate local diagnostic counts are in results.json.

In the local preview choose View the review packet. It opens through the same
private authenticated loopback session; no extraction or extra software needed.
The ZIP is an optional copy. If Chrome blocks file:// HTML, serve the extracted
folder with: python3 -m http.server 8000 --bind 127.0.0.1
Then open http://localhost:8000/ on that computer. No public hosting is involved.

Founder checks (three only):
1. Explain your part and a fictional timeline; use Back/Forward and read the takeaway.
2. Try one refusal or confirmed resignation.
3. Change a private drafting goal to risks/support; optionally record/listen back.

reviewedRuntimeRevision: e943fe25dfeaf4e56fe96a2685283e5a9e258474
runtimeHash: 3f6437526356fa08d6d2f7f24c3b228e54876d1a3e3c057401d877b13b78de9a
The final source SHA appears in the pinned launch block and preview banner.
The archive cannot contain the hash of its own containing commit. The launcher
verifies the entire final source archive; verify_preview.cjs checks all captured
runtime hashes against that exact revision, the actual pages and assets, two
fresh launches and the rendered packet/report. It tests the simulator's zero
storage of answers separately from the report's harmless UI theme preference.

All screenshots, video and trace use fictional typed inputs. The video is silent;
there is no microphone recording, private founder response or private register.
Language remains scripted. Hardware audio, live speech-provider behavior and
screen-reader output have not been manually validated. Typing remains available.
No merge, public release, deployment or spending is authorized.
