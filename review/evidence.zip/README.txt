UNRELEASED HUMAN LITERACY REVIEW PACKET

Open index.html in Chrome after extracting this ZIP. No account or service needed.
The Playwright report is report/index.html. Screenshots use synthetic inputs only.
The video is silent, synthetic and typed-only. The trace ZIP has typed-only
snapshots and no audio; use Playwright trace viewer locally if desired.

The independent interactive preview is launched using the separately supplied
pinned Python block. Its full source SHA identifies the exact delivery revision.
The captured runtime is frozen at cbe6217; after/capture-results.json records every
site asset hash, verified against the final source revision by verify_preview.cjs.
The packet cannot embed the hash of the commit that contains the packet itself.

Founder checks (three only):
1. Complete a main conversation: select/edit, Say this, Back/Forward, finish.
2. Retry a refusal/resignation or unexpected/hostile response; no fake grade.
3. Try one optional Coach or local recording/listen-back feature.

Typing is always available. Dictation is separately consented browser-provider
processing and is not validated with a live provider. Physical microphone quality,
assistive technology and founder acceptance of this exact revision remain pending.
No merge, public deployment, spending or paid service was performed.
