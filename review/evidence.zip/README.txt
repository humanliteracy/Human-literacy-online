UNRELEASED HUMAN LITERACY REVIEW — 353 full-suite cases
Actual test results and their source identity are in results.json.

In the local preview choose View the review packet. It opens through the same
private authenticated loopback session; no extraction or extra software needed.
The ZIP is an optional copy. If Chrome blocks file:// HTML, serve the extracted
folder with: python3 -m http.server 8000 --bind 127.0.0.1
Then open http://localhost:8000/ on that computer. No public hosting is involved.

Founder checks (three only):
1. Help me draft: enter an immediate, final resignation with no further project work. Check all conditions stay in the goal and wording.
2. Use this wording, review/edit, then Say this. Check Jordan acknowledges resignation and its conditions; choose Finish here and read the takeaway.
3. Back/Forward should restore progress without sending. Editing your reply to a pause should produce a pause, not resignation.

reviewedRuntimeRevision: 9af25c31f8585600ba83358e173deda2589fdaf8
runtimeHash: 3b3ca27482ced4e23c8bc9e8adecac928398c32bfc0475373842949b81bc26ab
The final source SHA appears in the pinned launch block and preview banner.
The archive cannot contain the hash of its own containing commit. The launcher
verifies the entire final source archive; verify_preview.cjs checks all captured
runtime hashes against that exact revision, the actual pages and assets, two
fresh launches and the rendered packet/report. It tests the simulator's zero
storage of answers separately from the report's harmless UI theme preference.

All screenshots and traces use fictional typed inputs. Any video is silent;
there is no microphone recording, private founder response or private register.
Language remains scripted. Hardware audio, live speech-provider behavior and
screen-reader output have not been manually validated. Typing remains available.
No merge, public release, deployment or spending is authorized.
