UNRELEASED HUMAN LITERACY REVIEW — 240 full-suite cases
Full CI results and separate local diagnostic counts are in results.json.

In the local preview choose View the review packet. It opens through the same
private authenticated loopback session; no extraction or extra software needed.
The ZIP is an optional copy. If Chrome blocks file:// HTML, serve the extracted
folder with: python3 -m http.server 8000 --bind 127.0.0.1
Then open http://localhost:8000/ on that computer. No public hosting is involved.

Founder checks (three only):
1. Complete a main conversation; use Back/Forward and read the takeaway.
2. Try a refusal, resignation or an unexpected/hostile reply.
3. Try one optional Coach or recording/listen-back feature.

reviewedRuntimeRevision: 8591ed59eabf7e9a4660cf8dde5d3d880aa5b71b
runtimeHash: 33d93819e11ce1d02ef111976efcd1c6eb2d1c5cdd8a7b553ebe66d46c1ac205
The final source SHA appears in the pinned launch block and preview banner.
The archive cannot contain the hash of its own containing commit. The launcher
verifies the entire final source archive; verify_preview.cjs checks all captured
runtime hashes against that exact revision, the actual pages and assets, two
fresh launches and the rendered packet/report. It tests the simulator's zero
storage of answers separately from the report's harmless UI theme preference.

All screenshots, video and trace use fictional typed inputs. The video is silent;
there is no microphone recording, private founder response or private register.
Language remains scripted. Hardware audio, live speech-provider behavior and
screen-reader output have not been manually validated. Typing remains available.
No merge, public release, deployment or spending is authorized.
